create view view_user as
select `bank`.`comstuer`.`nameid`  AS `客户编号`,
       `bank`.`comstuer`.`cName`   AS `客户名字`,
       `bank`.`comstuer`.`phone`   AS `联系方式`,
       `bank`.`comstuer`.`address` AS `居住地址`
from `bank`.`comstuer`;

