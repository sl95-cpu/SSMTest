create view view_account as
select `a`.`bcardID`  AS `卡号`,
       `c`.`cName`    AS `客户`,
       `a`.`bz`       AS `货币种类`,
       `s`.`typename` AS `存款类型`,
       `a`.`khtime`   AS `开户时间`,
       `a`.`khmoney`  AS `余额`,
       `a`.`guashi`   AS `是否挂失`
from ((`bank`.`account` `a` join `bank`.`comstuer` `c` on ((`c`.`nameid` = `a`.`nameid`)))
       join `bank`.`service` `s` on ((`s`.`typeid` = `a`.`ctypeID`)));

