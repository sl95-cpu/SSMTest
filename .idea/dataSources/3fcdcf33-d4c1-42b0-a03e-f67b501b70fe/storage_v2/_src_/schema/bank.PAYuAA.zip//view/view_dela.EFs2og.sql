create view view_dela as
select `bank`.`dela`.`dtime`   AS `交易日期`,
       `bank`.`dela`.`typeid`  AS `交易类型`,
       `bank`.`dela`.`bcardID` AS `卡号`,
       `bank`.`dela`.`dmoney`  AS `交易金额`,
       `bank`.`dela`.`coment`  AS `备注`
from `bank`.`dela`;

